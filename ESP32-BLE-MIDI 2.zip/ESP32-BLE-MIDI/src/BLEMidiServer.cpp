#define BLE_MIDI_DEBUG
#include "BLEMidiServer.h"
#include <queue>
#include <Ticker.h>

static Ticker midiSendTicker;
static std::queue<std::vector<uint8_t>> midiQueue;
static NimBLEServer* g_pServer = nullptr;

// ======================================================
//   DEBUG CALLBACKS (универсально без override)
// ======================================================
class MidiNotifyCallback : public NimBLECharacteristicCallbacks {
public:
    void onSubscribe(NimBLECharacteristic* pCharacteristic, ble_gap_conn_desc* desc, uint16_t subValue) {
        Serial.printf("📡 [BLE DEBUG] Client %s subscribed (0x%04X)\n",
                      NimBLEAddress(desc->peer_ota_addr).toString().c_str(), subValue);
    }
    void onUnsubscribe(NimBLECharacteristic* pCharacteristic, ble_gap_conn_desc* desc) {
        Serial.printf("📴 [BLE DEBUG] Client %s unsubscribed\n",
                      NimBLEAddress(desc->peer_ota_addr).toString().c_str());
    }
};

class CombinedServerCallbacks : public NimBLEServerCallbacks {
public:
    CombinedServerCallbacks(BLEMidiServerClass* midiServer) : _midiServer(midiServer) {}
    void onConnect(NimBLEServer* pServer) {
        Serial.println("🟢 [BLE DEBUG] onConnect()");
        if (_midiServer) _midiServer->onConnect(pServer);
    }
    void onDisconnect(NimBLEServer* pServer) {
        Serial.println("🔴 [BLE DEBUG] onDisconnect()");
        if (_midiServer) _midiServer->onDisconnect(pServer);
    }
    void onMTUChange(uint16_t MTU, NimBLEConnInfo &connInfo) {
        Serial.printf("📏 [BLE DEBUG] MTU changed: %u\n", MTU);
    }
private:
    BLEMidiServerClass* _midiServer;
};

class MidiConnectionWatcher : public NimBLECharacteristicCallbacks {
    BLEMidiServerClass* _midiServer;
public:
    MidiConnectionWatcher(BLEMidiServerClass* server) : _midiServer(server) {}
    void onSubscribe(NimBLECharacteristic* c, ble_gap_conn_desc* desc, uint16_t subValue) {
        Serial.println("🎶 [BLE DEBUG] Client subscribed — connected");
        if (_midiServer) _midiServer->setConnected(true);
    }
    void onUnsubscribe(NimBLECharacteristic* c, ble_gap_conn_desc* desc) {
        Serial.println("🔕 [BLE DEBUG] Client unsubscribed — disconnected");
        if (_midiServer) _midiServer->setConnected(false);
    }
};
// ======================================================
//   BEGIN()
// ======================================================
void BLEMidiServerClass::begin(const std::string deviceName) {
    Serial.println("🔧 BLEMidiServer.begin() start");

    NimBLEDevice::init(deviceName);
    NimBLEDevice::setSecurityAuth(false, false, false);
    NimBLEDevice::setSecurityIOCap(BLE_HS_IO_NO_INPUT_OUTPUT);
    NimBLEDevice::setPower(ESP_PWR_LVL_P9);

    NimBLEServer* pServer = NimBLEDevice::createServer();
    pServer->setCallbacks(new CombinedServerCallbacks(this));

    // --- Device Info Service (macOS / iOS requirement) ---
    NimBLEService* deviceInfo = pServer->createService("180A");
    deviceInfo->createCharacteristic("2A29", NIMBLE_PROPERTY::READ)->setValue("Cardputer Labs");
    deviceInfo->createCharacteristic("2A24", NIMBLE_PROPERTY::READ)->setValue("Cardputer MIDI SEQ");
    deviceInfo->start();

    // --- MIDI Service ---
    NimBLEService* pService = pServer->createService("03B80E5A-EDE8-4B33-A751-6CE34EC4C700");

    pCharacteristic = pService->createCharacteristic(
        "7772E5DB-3868-4112-A1A9-F2669D106BF3",
        NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR | NIMBLE_PROPERTY::NOTIFY
    );

    NimBLEDescriptor* cccd = pCharacteristic->createDescriptor("2902", NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE, true);
    uint8_t initVal[2] = {0x00, 0x00};
    cccd->setValue(initVal, 2);

    // --- Callbacks ---
    pCharacteristic->setCallbacks(new MidiNotifyCallback());
    pCharacteristic->setCallbacks(new MidiConnectionWatcher(this));

    pService->start();

    // --- BLE Advertising (Cross-platform CoreMIDI friendly) ---
    NimBLEAdvertising* pAdvertising = NimBLEDevice::getAdvertising();
    NimBLEAdvertisementData advData;
    NimBLEAdvertisementData scanResp;

    advData.setFlags(0x06);
    advData.addServiceUUID("03B80E5A-EDE8-4B33-A751-6CE34EC4C700");
    advData.setAppearance(0x03C4);
    advData.setName(deviceName);

    std::string mfgData = "\x4F\x4E" "MIDI"; // manufacturer ID + tag
    advData.setManufacturerData(mfgData);

    scanResp.setName(deviceName);

    pAdvertising->setAdvertisementData(advData);
    pAdvertising->setScanResponseData(scanResp);
    pAdvertising->start();

    Serial.println("🎵 [BLE] Advertising started for CoreMIDI / Android / Win10");

    // --- Enable CCCD ---
    if (pCharacteristic) {
        NimBLEDescriptor* desc = pCharacteristic->getDescriptorByUUID("2902");
        if (desc) {
            uint8_t notifyEnable[2] = {0x01, 0x00};
            desc->setValue(notifyEnable, 2);
            connected = true;
            Serial.println("🎧 [BLE FIX] Notifications enabled");
        }
    }

    // --- MIDI sending ticker ---
    midiSendTicker.attach_ms(4, []() {
        static bool busy = false;
        static uint32_t lastSend = 0;
        if (busy || midiQueue.empty() || !BLEMidiServer.isConnected()) return;
        if (millis() - lastSend < 6) return;
        busy = true;
        auto packet = midiQueue.front();
        midiQueue.pop();
        BLEMidiServer.sendImmediate(packet.data(), packet.size());
        busy = false;
        lastSend = millis();
    });

    Serial.println("✅ BLE-MIDI ready (cross-platform optimized)");
}

// ======================================================
//   CONNECTION EVENTS
// ======================================================
void BLEMidiServerClass::onConnect(NimBLEServer* pServer) {
    connected = true;
    Serial.println("🎹 BLE MIDI client connected!");
    if (onConnectCallback) onConnectCallback();
}

void BLEMidiServerClass::onDisconnect(NimBLEServer* pServer) {
    connected = false;
    Serial.println("🔌 BLE client disconnected → restart advertising");
    if (onDisconnectCallback) onDisconnectCallback();
    pServer->startAdvertising();
}

// ======================================================
//   SEND PACKET (with BLE-MIDI format)
// ======================================================
void BLEMidiServerClass::sendImmediate(uint8_t *packet, uint8_t packetSize) {
    if (!connected || packetSize == 0) return;

    uint8_t blePacket[20];
    uint8_t len = 0;

    // === macOS-safe CoreMIDI header ===
    // Первый байт всегда 0x80 (timestamp high nibble)
    blePacket[len++] = 0x80;
    blePacket[len++] = 0x80 | ((millis() >> 6) & 0x3F);

    // === Добавляем MIDI payload ===
    memcpy(&blePacket[len], packet, packetSize);
    len += packetSize;

    // === Отправка ===
    pCharacteristic->setValue(blePacket, len);
    pCharacteristic->notify();

#ifdef BLE_MIDI_DEBUG
    Serial.printf("[BLE_MIDI macOS-fix] TX (%d bytes): ", len);
    for (int i = 0; i < len; i++) Serial.printf("%02X ", blePacket[i]);
    Serial.println();
#endif
}

void BLEMidiServerClass::sendPacket(uint8_t *packet, uint8_t packetSize) {
    sendQueued(packet, packetSize);
}

void BLEMidiServerClass::sendQueued(uint8_t *packet, uint8_t packetSize) {
    if (packetSize == 0) return;
    std::vector<uint8_t> midiPacket;
    for (int i = 0; i < packetSize; i++) {
        if (i > 0 && (packet[i] & 0x80) && (packet[i - 1] & 0x80)) continue;
        midiPacket.push_back(packet[i]);
    }
    Serial.print("Raw MIDI bytes (clean): ");
    for (auto b : midiPacket) Serial.printf("%02X ", b);
    Serial.println();
    midiQueue.push(midiPacket);
}

// ======================================================
//   CHARACTERISTIC CALLBACKS
// ======================================================
CharacteristicCallback::CharacteristicCallback(std::function<void(uint8_t*, uint8_t)> cb)
: onWriteCallback(cb) {}

void CharacteristicCallback::onWrite(NimBLECharacteristic *pCharacteristic) {
    std::string val = pCharacteristic->getValue();
    if (val.length() > 0 && onWriteCallback)
        onWriteCallback((uint8_t*)val.c_str(), val.length());
}

// ======================================================
//   STATIC INSTANCE
// ======================================================
BLEMidiServerClass BLEMidiServer;